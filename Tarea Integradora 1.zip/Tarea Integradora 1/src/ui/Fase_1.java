import java.util.Scanner;

public class Fase_1 {
    /**
     * @param pNombre Nombre del participante. pNombre != null && pNombre != "".
     * @param pCedula Cedula del participante. pCedula != null && pCedula != "".
     * @param pParticpantes Numero de participantes. pParticpantes != null && pParticipantes != "".
     * @param pGuias Numero de guias. pGuias != null && pGuias != "".
     * @param args
     */
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese su nombre y digite su cedula");
        System.out.print("Ingrese su nombre: ");
        String Nombre = scanner.nextLine();
        System.out.print("Ingrese su cedula: ");
        String Cedula = scanner.nextLine();
        System.out.println("Bienvenido a la COP16 " + Nombre + " cedula: " + Cedula);

        String Ruta = Seleccionruta(scanner);
        Informacionderuta(Ruta);

        System.out.print("Digite la cantidad de participantes: ");
        int Participantes = scanner.nextInt();
        System.out.print("Digite la cantidad de guias: ");
        int Guias = scanner.nextInt();
        int Total_Participantes = (Participantes + Guias);
        System.out.println("El total de participantes es: " + Total_Participantes);

        System.out.print("Ingrese la temperatura en grados centigrados: ");
        double Temperatura = scanner.nextDouble();
        System.out.print("Igrese el porcentaje de humedad relativa: ");
        int Humedad = scanner.nextInt();
        clima(Temperatura, Humedad);

        busestotales(Participantes + Guias);
        
        scanner.close();

    }
    //Selección de rutas
    public static String Seleccionruta (Scanner scanner){
        System.out.println("Por favor, seleccione una de las siguientes rutas:");
        System.out.println("RUTA 1: Ruta Ladera");
        System.out.println("RUTA 2: Ruta del Oriente");
        System.out.println("RUTA 3: Ruta Farallones");
        return scanner.nextLine();

    }

    //Información de las rutas
    /** 
     * @param pRuta Seleccione la ruta. pRuta != null && pRuta != "". 
    */
    public static void Informacionderuta(String opcionderuta){
        if (opcionderuta.equalsIgnoreCase("Ruta Ladera")){
            System.out.println("Muy bien!! Esta ruta inicia a las 7:00am y termina a la 1:30pm, el punto de encuentro es en el Bulevar del Rio.");
        }
        else if (opcionderuta.equalsIgnoreCase("Ruta del Oriente")){
            System.out.println("Muy bien!! Esta ruta inicia a las 7:00am y termina a la 1:00pm, el punto de encuentro es en el Bulevar del Rio.");
        }
        else if (opcionderuta.equalsIgnoreCase("Ruta Farallones")){
            System.out.println("Muy bien!! Esta ruta inica a las 6:40am y termina a las 2:30pm, el punto de encuentro es en la Universidad del Valle.");
        }
        else {
            System.out.println("Opción no valida");
        }
    }
    
    //Dependiendo de la temperatura y humedad, se sabe si hace un  buen dia o no
    /**
     * @param pTemperatura La temperatura está o no está dentro de los terminos para salir. pumedad != null && pHumedad != "".
     * @param pHumedad La humedad está o no está dentro de los terminos para salir. pHumedad != null && pHumedad != "".
     */
    public static void clima(double Temperatura, int Humedad){
        if (Temperatura >= 20 && Temperatura <= 25 && Humedad >= 40 && Humedad <= 60){
            System.out.println("¡Hace un buen día para caminar por Cali!");
        }
        else{
            System.out.println("El clima no es adecuado para salir");
        }
    }
    //Cantidad de buses para las rutas
    public static int busestotales(int Total_Participantes){
        int capacidadbus = 25;
        int buses = (Total_Participantes / capacidadbus);
        if(Total_Participantes % capacidadbus != 0){
            buses++;
        }
        System.out.println("Se requieren " + buses + " buses para transportar a las personas.");
        return buses;
    }
}


    
